﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVC.Excercise.Web.Data;
using MVC.Excercise.Web.Models;
using MVC.Excercise.Web.Models.Event;

namespace MVC.Excercise.Web.Controllers
{
    public class BookReadingEventsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookReadingEventsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: BookReadingEvents
        public async Task<IActionResult> Index()
        {
            var events = _context.BookReadingEvents.AsQueryable<BookReadingEvent>();
            if (!User.Identity.IsAuthenticated)
            {
                events = events.Where(x => x.Type == EventTypes.Public);
            }
            return View(await events.ToListAsync());
        }

        [Authorize]
        public async Task<IActionResult> MyEvents()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var events = await _context.BookReadingEvents.Where(x=> x.CreatedBy == userId)
                .ToListAsync();
            return View(events);
        }

        // GET: BookReadingEvents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookReadingEvent = await _context.BookReadingEvents
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookReadingEvent == null)
            {
                return NotFound();
            }

            return View(bookReadingEvent);
        }

        // GET: BookReadingEvents/Create
        [Authorize]
        public IActionResult Create()
        {
            SetTypesInViewBag();
            return View();
        }

        // POST: BookReadingEvents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Date,Location,StartTime,Type,Duration,Description,OtherDetails,Invitations,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate")] BookReadingEvent bookReadingEvent)
        {
            SetTypesInViewBag();
            if (ModelState.IsValid)
            {
                bookReadingEvent.CreatedBy = User.FindFirstValue(ClaimTypes.NameIdentifier);
                bookReadingEvent.CreatedDate = DateTime.UtcNow;
                _context.Add(bookReadingEvent);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bookReadingEvent);
        }

        [Authorize]
        // GET: BookReadingEvents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {   
            SetTypesInViewBag();
            if (id == null)
            {
                return NotFound();
            }

            var bookReadingEvent = await _context.BookReadingEvents.FindAsync(id);
            if (bookReadingEvent == null)
            {
                return NotFound();
            }
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (bookReadingEvent.CreatedBy != userId)
            {
                return Forbid();
            }
            return View(bookReadingEvent);
        }

        // POST: BookReadingEvents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Date,Location,StartTime,Type,Duration,Description,OtherDetails,Invitations,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate")] BookReadingEvent bookReadingEvent)
        {
            SetTypesInViewBag();
            if (id != bookReadingEvent.Id)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (bookReadingEvent.CreatedBy != userId)
            {
                return Forbid();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    bookReadingEvent.UpdatedBy = userId;
                    bookReadingEvent.UpdatedDate = DateTime.UtcNow;
                    _context.Update(bookReadingEvent);
                    await _context.SaveChangesAsync();
                    
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookReadingEventExists(bookReadingEvent.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookReadingEvent);
        }

        // GET: BookReadingEvents/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            SetTypesInViewBag();
            if (id == null)
            {
                return NotFound();
            }

            var bookReadingEvent = await _context.BookReadingEvents
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookReadingEvent == null)
            {
                return NotFound();
            }
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (bookReadingEvent.CreatedBy != userId)
            {
                return Forbid();
            }

            return View(bookReadingEvent);
        }

        // POST: BookReadingEvents/Delete/5
        [Authorize]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bookReadingEvent = await _context.BookReadingEvents.FindAsync(id);
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (bookReadingEvent.CreatedBy != userId)
            {
                return Forbid();
            }
            _context.BookReadingEvents.Remove(bookReadingEvent);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookReadingEventExists(int id)
        {
            return _context.BookReadingEvents.Any(e => e.Id == id);
        }

        private void SetTypesInViewBag()
        {
            ViewBag.EventTypes = new List<KeyValue>
            {
                new KeyValue { Id = 0, Value = "Public" },
                new KeyValue { Id = 1, Value = "Private" }
            };
        }
    }
}
