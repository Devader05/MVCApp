﻿namespace MVC.Excercise.Web.Models.Event
{
    public enum EventTypes
    {
        Public,
        Private
    }
}
