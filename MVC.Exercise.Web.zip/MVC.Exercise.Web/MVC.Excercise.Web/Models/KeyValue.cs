﻿namespace MVC.Excercise.Web.Models
{
    public class KeyValue
    {
        public int Id { get; set; }
        public string Value { get; set; }
    }
}
