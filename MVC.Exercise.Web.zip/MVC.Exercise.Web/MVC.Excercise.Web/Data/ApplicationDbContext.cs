﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MVC.Excercise.Web.Models.Event;
using System;
using System.Collections.Generic;
using System.Text;

namespace MVC.Excercise.Web.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<BookReadingEvent> BookReadingEvents { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
